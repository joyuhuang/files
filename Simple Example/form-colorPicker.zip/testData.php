<!-- 表單資料傳遞測試 & 下一頁指示 -->
<?php
var_dump($_REQUEST);
echo '<br><br>';

// modifyAdd.php 的下一頁
if (isset($_POST['company'])) {
	echo '<a href="modifyView.php">應該前往的頁面</a>';
}